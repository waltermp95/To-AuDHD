# To-AUDHD App
Deployment-ready starter assets.

## Includes
- .gitignore
- Firebase config
- Vercel config
- GitHub Actions workflow
