import { auth, googleProvider } from '../lib/firebase';
import { signInWithPopup, signInWithEmailAndPassword } from 'firebase/auth';
export default function Login(){return (<div className='p-6 text-white'>Login Page — Google + Email planned</div>);}